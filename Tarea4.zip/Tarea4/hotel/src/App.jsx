import { useState } from 'react';
import Swal from 'sweetalert2';
import './App.css';

const App = () => {
  const [formData, setFormData] = useState({
    identificacion: "",
    nombres: "",
    apellidos: "",
    telefono: "",
    habitacion: "",
    rh: "O+",
    fechaIngreso: "",
    fechaSalida: ""
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault(); // Evita recargar la página

    const { identificacion, nombres, apellidos, telefono, habitacion, fechaIngreso, fechaSalida } = formData;

    if (!identificacion || !nombres || !apellidos || !telefono || !habitacion || !fechaIngreso || !fechaSalida) {
      Swal.fire({
        title: "Error",
        text: "Todos los campos son obligatorios",
        icon: "error",
        confirmButtonText: "Aceptar"
      });
      return;
    }

    Swal.fire({
      title: "¡Registro exitoso!",
      text: "Los datos han sido guardados correctamente",
      icon: "success",
      confirmButtonText: "Aceptar"
    });
  };

  const handleCancel = () => {
    Swal.fire({
      title: "¿Cancelar registro?",
      text: "Perderás los datos ingresados",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Sí, cancelar",
      cancelButtonText: "No, volver",
    }).then((result) => {
      if (result.isConfirmed) {
        setFormData({
          identificacion: "",
          nombres: "",
          apellidos: "",
          telefono: "",
          habitacion: "",
          rh: "O+",
          fechaIngreso: "",
          fechaSalida: ""
        });

        Swal.fire({
          title: "Cancelado",
          text: "El registro ha sido cancelado",
          icon: "info",
          confirmButtonText: "Aceptar"
        });
      }
    });
  };

  return (
    <>
      <form>
        <h3>REGISTRO HOTEL</h3>
        <div className="App">
          <label htmlFor="identificacion">Identificación:</label>
          <input type="text" id="identificacion" name="identificacion" value={formData.identificacion} onChange={handleChange} /> <br />

          <label htmlFor="nombres">Nombres:</label>
          <input type="text" id="nombres" name="nombres" value={formData.nombres} onChange={handleChange} /> <br />

          <label htmlFor="apellidos">Apellidos:</label>
          <input type="text" id="apellidos" name="apellidos" value={formData.apellidos} onChange={handleChange} /> <br />

          <label htmlFor="telefono">Teléfono:</label>
          <input type="text" id="telefono" name="telefono" value={formData.telefono} onChange={handleChange} /> <br />

          <label htmlFor="habitacion">Habitación:</label>
          <input type="text" id="habitacion" name="habitacion" value={formData.habitacion} onChange={handleChange} /> <br />

          <label htmlFor="rh">RH:</label>
          <select name="rh" id="rh" value={formData.rh} onChange={handleChange}>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
          </select>
        </div>
        
        <div>
          <label htmlFor="fechaIngreso">Fecha Ingreso</label>
          <input type="date" name="fechaIngreso" id="fechaIngreso" value={formData.fechaIngreso} onChange={handleChange} />

          <label htmlFor="fechaSalida">Fecha Salida</label>
          <input type="date" name="fechaSalida" id="fechaSalida" value={formData.fechaSalida} onChange={handleChange} />
        </div>

        <div className="buttons">
          <button className="btn btn-primary" onClick={handleSubmit}>Registrar</button>
          <button className="btn btn-danger" type="button" onClick={handleCancel}>Cancelar</button>
        </div>
      </form>
    </>
  );
}

export default App;
